/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio1;

import javax.swing.*;

public class Ejercicio1 {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(
            null, 
            "Un aviso"
        );

        System.out.println("ya estas avisado");
    }
}
